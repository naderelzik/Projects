package networks;
import java.io.*; 
import java.net.*;
public class TCPServer {
static Socket connectionSocket;
	public static void main(String argv[]) throws Exception 
    { 
      String clientSentence; 
      String capitalizedSentence; 

      ServerSocket welcomeSocket = new ServerSocket(6789); 
   
            connectionSocket = welcomeSocket.accept(); 
            
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
					
					BufferedReader inFromClient;
              
           DataOutputStream  outToClient;
					
					while(true){
					
					inFromClient = 
              new BufferedReader(new
              InputStreamReader(connectionSocket.getInputStream()));
              
              outToClient = 
                   new DataOutputStream(connectionSocket.getOutputStream());
					
					clientSentence = inFromClient.readLine();
                 System.out.println("From Client: " + clientSentence);
                 if(clientSentence.equals("q")){
									System.out.println("Disconnecting...");
									outToClient.close();
									break;
								}

								 System.out.print("From Server: ");
                 capitalizedSentence = inFromUser.readLine() + '\n';
                 
                 //System.out.print(capitalizedSentence);

                 outToClient.writeBytes(capitalizedSentence);
					}
			}
}
