package view;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Simulatable;
import simulation.Simulator;

public class RescueSimulationView extends JFrame {
	private JPanel pnlCells;
	private JTextArea txtCells;
	private JTextArea txtLog;
	public RescueSimulationView() {
		setTitle("Rescue Simulation");
		JLabel label1 = new JLabel("Please enter your username");
		label1.setBackground(Color.red);
		label1.setOpaque(true);
		label1.setBounds(10,10,200,20);
		getContentPane().add(label1);
		JButton b1= new JButton();
		b1.setText("Sign in");
		b1.setBounds(10, 70, 100, 20);
		getContentPane().add(b1);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(50, 50, 800, 600);
		pnlCells = new JPanel();
		pnlCells.setLayout(new GridLayout(10, 10));
		add(pnlCells, BorderLayout.CENTER);
		txtCells = new JTextArea();
		txtCells.setPreferredSize(new Dimension(200, getHeight()));
		txtCells.setEditable(false);
		txtCells.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		add(txtCells, BorderLayout.EAST);
		txtLog = new JTextArea();
		txtLog.setPreferredSize(new Dimension(200, 300));
		txtLog.setEditable(false);
		txtLog.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		add(txtLog, BorderLayout.EAST);
		JTextField txt1= new JTextField();
		getContentPane().add(txt1);
		txt1.setBounds(8,40,150,20);
		JLabel background = new JLabel();
		background.setBounds(0, 0, 800, 600);
		background.setIcon(new ImageIcon("/Users/naderelzik/desktop/Saw.jpg"));
		getContentPane().add(background);
		

		
		
		
	}
	
	public void addSimulatable(JButton Simulatable) {
		pnlCells.add(Simulatable);
	}
	
	public void updateInfo(Simulatable s) {
		String info = "";
		if(s instanceof ResidentialBuilding) {
			
		info += "Information:\n";
		info += "-" + "Location: " + "(" + ((ResidentialBuilding) s).getLocation().getX() + "," + ((ResidentialBuilding) s).getLocation().getX() + ")" + "\n";
		info += "-" + "Structural Integrity: " + ((ResidentialBuilding) s).getStructuralIntegrity() + "\n";
		info += "-" + "Fire Damage: " + ((ResidentialBuilding) s).getFireDamage() + "\n";
		info += "-" + "Gas Level: " + ((ResidentialBuilding) s).getGasLevel() + "\n";
		info += "-" + "Foundation Damage: " + ((ResidentialBuilding) s).getFoundationDamage() + "\n";
		info += "-" + "Number Of Occupants: " + ((ResidentialBuilding) s).getOccupants().size() + "\n";
		for(int i = 0; i < ((ResidentialBuilding) s).getOccupants().size(); i++ ) {
			Citizen c = ((ResidentialBuilding) s).getOccupants().get(i);
			info += "-" + "Occupants Info: " + "\n";
			info += "Name: " + c.getName() + "\n";
			info += "Age: " + c.getAge() + "\n";
			info += "National ID: " + c.getNationalID() + "\n";
			info += "HP: " + c.getHp() + "\n";
			info += "Blood Loss: " + c.getBloodLoss() + "\n";
			info += "Toxicity: " + c.getToxicity() + "\n";
			info += "State: " + c.getState() + "\n";
			if(c.getDisaster() != null)
			info += "Disaster: " + c.getDisaster() + "\n";
		}
		
		info += "-" + "Disaster: " + ((ResidentialBuilding) s).getDisaster() + "\n";
		
		}
		
		else if(s instanceof Citizen) {
			
			info += "Name: " + ((Citizen) s).getName() + "\n";
			info += "Age: " + ((Citizen) s).getAge() + "\n";
			info += "National ID: " + ((Citizen) s).getNationalID() + "\n";
			info += "HP: " + ((Citizen) s).getHp() + "\n";
			info += "Blood Loss: " + ((Citizen) s).getBloodLoss() + "\n";
			info += "Toxicity: " + ((Citizen) s).getToxicity() + "\n";
			info += "State: " + ((Citizen) s).getState() + "\n";
			if(((Citizen) s).getDisaster() != null)
			info += "Disaster: " + ((Citizen) s).getDisaster() + "\n";
			
		}
		
		txtCells.setText(info);
	}
	
	public void updateLog(ArrayList<String> executedDisasters) {
		String log = "";
		log = "Executed Disasters:\n ";
		for (int i = 0; i < executedDisasters.size(); i++) {
			if(executedDisasters.size() - i == 1)
				log += executedDisasters.get(i);
			else
				log += executedDisasters.get(i) + ", ";
				
		}
		
		txtLog.setText(log);
		
	}
	public static void main (String[]args) {
		RescueSimulationView r= new RescueSimulationView();
		r.setVisible(true);
	}


	
}
