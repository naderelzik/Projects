package simulation;

public interface Simulatable {
public void cycleStep();
}
