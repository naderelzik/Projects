package model.disasters;

import model.people.Citizen;

public class Injury extends Disaster {

	public Injury(int startCycle, Citizen target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		super.cycleStep();
		Citizen citizen = (Citizen) this.getTarget();
		int bloodloss = citizen.getBloodLoss();
		bloodloss +=  10;
		citizen.setBloodLoss(bloodloss);
		
	}
	public void strike() {
		super.strike();
		int bloodloss = ((Citizen) this.getTarget()).getBloodLoss();
		bloodloss +=  30;
		((Citizen) this.getTarget()).setBloodLoss(bloodloss);
	}

}
