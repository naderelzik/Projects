package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class Collapse extends Disaster {

	public Collapse(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		super.cycleStep();
		int foundation = ((ResidentialBuilding) this.getTarget()).getFoundationDamage();
		foundation = foundation + 10;
		((ResidentialBuilding) this.getTarget()).setFoundationDamage(foundation);
		
	}
	
	public void strike() {
		super.strike();
		ResidentialBuilding building = (ResidentialBuilding) this.getTarget();
		int foundation = building.getFoundationDamage();
		foundation = foundation - 10;
		building.setFoundationDamage(foundation);
	}
	
	

}
