package model.disasters;

import model.people.Citizen;

public class Infection extends Disaster {

	public Infection(int startCycle, Citizen target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		super.cycleStep();
		Citizen citizen = (Citizen) this.getTarget();
		int toxicity = citizen.getToxicity();
		toxicity +=  15;
		citizen.setToxicity(toxicity);
		
	}
	
	public void strike() {
		super.strike();
		Citizen citizen = (Citizen) this.getTarget();
		int toxicity = citizen.getToxicity();
		toxicity +=  25;
		citizen.setToxicity(toxicity);
	}
	

}
