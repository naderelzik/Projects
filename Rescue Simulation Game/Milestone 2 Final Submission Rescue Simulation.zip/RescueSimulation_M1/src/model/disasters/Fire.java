package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class Fire extends Disaster {

	public Fire(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		super.cycleStep();
		ResidentialBuilding building = (ResidentialBuilding) this.getTarget();
		int damage = building.getFireDamage();
		damage = damage + 10;
		building.setFireDamage(damage);
		
	}
	
	public void strike() {
		super.strike();
		ResidentialBuilding building = (ResidentialBuilding) this.getTarget();
		int damage = building.getFireDamage();
		damage = damage + 10;
		building.setFireDamage(damage);
	}
	

}
