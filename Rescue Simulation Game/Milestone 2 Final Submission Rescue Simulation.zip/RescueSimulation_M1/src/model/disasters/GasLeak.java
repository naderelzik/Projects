package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class GasLeak extends Disaster {

	public GasLeak(int startCycle, ResidentialBuilding target) {

		super(startCycle, target);

	}

	@Override
	public void cycleStep() {
		super.cycleStep();
		ResidentialBuilding building = (ResidentialBuilding) this.getTarget();
		int leak = building.getGasLevel();
		leak = leak + 15;
		building.setGasLevel(leak);
		
	}
	
	public void strike() {
		super.strike();
		ResidentialBuilding building = (ResidentialBuilding) this.getTarget();
		int leak = building.getGasLevel();
		leak = leak + 10;
		building.setGasLevel(leak);
	}
	

}
