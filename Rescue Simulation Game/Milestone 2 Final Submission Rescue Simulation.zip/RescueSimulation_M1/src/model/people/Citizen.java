package model.people;

import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;
import model.disasters.Disaster;
import model.events.SOSListener;
import model.events.WorldListener;

public class Citizen implements Rescuable, Simulatable {

	private CitizenState state;
	private Disaster disaster;
	private String name;
	private String nationalID;
	private int age;
	private int hp;
	private int bloodLoss;
	private int toxicity;
	private Address location;
	private WorldListener worldListener;
	private SOSListener emergencyService;
	
	
	public Citizen(Address location, String nationalID, String name, int age, WorldListener worldlistener) {

		this.name = name;
		this.nationalID = nationalID;
		this.age = age;
		this.location = location;
		this.state = CitizenState.SAFE;
		this.hp = 100;
		this.worldListener = worldlistener;
		
	}

	public CitizenState getState() {
		return state;
	}

	public void setState(CitizenState state) {
		this.state = state;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		if (hp >=0 && hp<=100) {
			this.hp = hp;
		}
		else{
			if(hp > 100) {
				this.hp = 100;
			}
			else {	
				this.hp = 0;
			}
		}
		if (this.hp==0) {
			this.state = CitizenState.DECEASED;
		}
	}

	public int getBloodLoss() {
		return bloodLoss;
	}

	public void setBloodLoss(int bloodLoss) {
		if(bloodLoss < 0) {
			this.bloodLoss = 0;
		}
		
		else if(bloodLoss > 100) {
			this.bloodLoss = 100;
		}
		else {
			this.bloodLoss = bloodLoss; 
		}
		if (this.bloodLoss==100) {
			setHp(0);
		}
		
	}

	public int getToxicity() {
		return toxicity;
	}

	public void setToxicity(int toxicity) {
		if (toxicity >= 0 || toxicity <=100) {
			this.toxicity = toxicity;
		}
		else{
			if(toxicity > 100) {
				this.toxicity = 100;
			}
			else {
				this.toxicity = 0;
			}
		}
		if (this.toxicity==100) {
			setHp(0);
		}
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
		int x = location.getX();
		int y = location.getY();
	//	worldListener.assignAddress(this,x,y);
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public void setWorldListener(WorldListener worldListener) {
		this.worldListener = worldListener;
	}

	public void setEmergencyService(SOSListener emergencyService) {
		this.emergencyService = emergencyService;
	}

	public Disaster getDisaster() {
		return disaster;
	}

	public String getNationalID() {
		return nationalID;
	}

	@Override
	public void struckBy(Disaster d) {
		this.disaster = d;
		this.state = CitizenState.IN_TROUBLE;
		emergencyService.receiveSOSCall(this);
		
	}

	@Override
	public void cycleStep() {
		
		if((this.toxicity > 0 && this.toxicity < 30) || (this.bloodLoss > 0 && this.bloodLoss < 30))  {
			this.hp-=5;
		}
		
		
		else if((this.toxicity >= 30 && this.toxicity < 70) || (this.bloodLoss >= 30 && this.bloodLoss < 70)){
			this.hp-=10;
		}
		
		
		else if((this.toxicity >= 70) || (this.bloodLoss >= 70)) {
			this.hp-=15;
		}
		
		
		
		
	}
	


	}
	
		
	


