package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Address;

public class DiseaseControlUnit extends MedicalUnit{

	public DiseaseControlUnit(String unitID, Address location, int stepsPerCycle, WorldListener listener) {

		super(unitID, location, stepsPerCycle, listener);

	}

	public void treat() {
		super.treat();
		int toxicity = ((Citizen) this.getTarget()).getToxicity();
		toxicity -= this.getTreatmentAmount();
		((Citizen) this.getTarget()).setToxicity(toxicity);
		
	}
	
	public void jobsDone() {
		super.jobsDone();
		
		
	}
	

	
	

}
