package model.units;

import java.util.ArrayList;

import simulation.Address;
import model.events.SOSResponder;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;

public abstract class PoliceUnit extends Unit{

	private ArrayList<Citizen> passengers;
	private int maxCapacity;
	private int distanceToBase = 0;

	public PoliceUnit(String unitID, Address location, int stepsPerCycle, WorldListener worldListener, int maxCapacity) {

		super(unitID, location, stepsPerCycle, worldListener);
		passengers = new ArrayList<Citizen>();
		this.maxCapacity = maxCapacity;

	}

	public ArrayList<Citizen> getPassengers() {
		return passengers;
	}

	public int getDistanceToBase() {
		return distanceToBase;
	}

	public void setDistanceToBase(int distanceToBase) {
		this.distanceToBase = distanceToBase;
	}

	public int getMaxCapacity() {
		return maxCapacity;
	}
	
	public void jobsDone() {
		
		if(this instanceof Evacuator) {
		if(((ResidentialBuilding) this.getTarget()).getStructuralIntegrity() == 0 || (((ResidentialBuilding) this.getTarget()).getOccupants().size() == 0 && this.getPassengers().size() == 0)){
			super.jobsDone();
		}
		
		}
		
		
		
	}

}
