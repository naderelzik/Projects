package model.units;

import model.events.SOSResponder;
import model.events.WorldListener;
import model.people.Citizen;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public abstract class Unit implements Simulatable,SOSResponder {

	private String unitID;
	private UnitState state;
	private Address location;
	private Rescuable target;
	private int distanceToTarget;
	private int stepsPerCycle;
	private WorldListener worldListener;
	
	public void setDistanceToTarget(int distanceToTarget) {
		this.distanceToTarget = distanceToTarget;
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public void setWorldListener(WorldListener worldListener) {
		this.worldListener = worldListener;
	}

	public Unit(String unitID, Address location, int stepsPerCycle, WorldListener worldListener) {

		this.unitID = unitID;
		this.location = location;
		this.stepsPerCycle = stepsPerCycle;
		this.state = UnitState.IDLE;
		this.worldListener = worldListener;
		
	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
		int x = location.getX();
		int y = location.getY();
	
	}

	public String getUnitID() {
		return unitID;
	}

	public Rescuable getTarget() {
		return target;
	}

	public int getStepsPerCycle() {
		return stepsPerCycle;
	}
	
	public void cycleStep() {
		if(this.target != null) {
		if(this.state != UnitState.IDLE) {
		if(distanceToTarget == 0) {
			worldListener.assignAddress((Simulatable) this, this.getTarget().getLocation().getX(),  this.getTarget().getLocation().getY());
			state = UnitState.TREATING;
			this.treat();
		}
		else{
			 
		
			distanceToTarget -= stepsPerCycle;
			if(distanceToTarget <= 0) {
				distanceToTarget = 0;
				worldListener.assignAddress((Simulatable) this, this.getTarget().getLocation().getX(),  this.getTarget().getLocation().getY());
				
			}
		}
		}
		}
	}
	public void treat() {
		this.getTarget().getDisaster().setActive(false);
	}
	
	public void respond(Rescuable r) {
		
			if(this.state != UnitState.IDLE) {
			this.target.getDisaster().setActive(true);
			
			}
			this.target = r;
			int distanceX = this.target.getLocation().getX();
			int distanceY = this.target.getLocation().getY();
			this.distanceToTarget = (distanceX - this.location.getX()) + (distanceY - this.location.getY());
			this.setState(UnitState.RESPONDING);
	
	}
	
	public void jobsDone() {
			this.state = UnitState.IDLE;
			this.target = null;
		
	}
}
