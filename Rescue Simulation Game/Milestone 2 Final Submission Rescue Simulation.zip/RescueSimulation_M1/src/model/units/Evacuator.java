package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;

public class Evacuator extends PoliceUnit{

	public Evacuator(String unitID, Address location, int stepsPerCycle, WorldListener listener, int maxCapacity) {

		super(unitID, location, stepsPerCycle, listener,maxCapacity);

	}

	@Override
	public void cycleStep() {
		super.cycleStep();
		
		
	}
	
	public void treat() {
		super.treat();
		if(this.getPassengers().size() != this.getMaxCapacity()) {
		
			for(int i = 0; i < this.getMaxCapacity(); i++) {
				System.out.println(((ResidentialBuilding) this.getTarget()).getOccupants().get(i).getName());
				this.getPassengers().add(((ResidentialBuilding) this.getTarget()).getOccupants().get(i));
			}
			for(int i = 0; i < this.getMaxCapacity(); i++) {
				Citizen c=((ResidentialBuilding) this.getTarget()).getOccupants().remove(0);
				System.out.println(c.getName());
			}

			this.setDistanceToBase(this.getTarget().getLocation().getX() + this.getTarget().getLocation().getY());
		}
		else if(this.getPassengers().size() == this.getMaxCapacity() && this.getDistanceToBase() > 0) {
			this.setDistanceToBase(this.getDistanceToBase() - this.getStepsPerCycle());
			if(this.getDistanceToBase() <= 0) {
				this.setDistanceToBase(0);
				this.getWorldListener().assignAddress(this, 0, 0);
			}
		}
		else if(this.getPassengers().size() == this.getMaxCapacity() && this.getDistanceToBase() == 0) {
			for(int i = 0; i < this.getMaxCapacity(); i++) {
				this.getPassengers().get(i).setState(CitizenState.RESCUED);
				this.getWorldListener().assignAddress(this.getPassengers().get(i), 0, 0);
				//System.out.println(this.getPassengers().get(i).getName());
			}
			this.getPassengers().clear();
			this.getWorldListener().assignAddress(this, 0, 0);
			this.setDistanceToTarget(this.getTarget().getLocation().getX() + this.getTarget().getLocation().getY());
			this.jobsDone();
		}
		
	}
	
	public void jobsDone() {
		
		
		
		super.jobsDone();
	}
	
	
		
}