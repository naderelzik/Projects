package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;

public class GasControlUnit extends FireUnit{

	public GasControlUnit(String unitID, Address location, int stepsPerCycle, WorldListener listener) {

		super(unitID, location, stepsPerCycle, listener);

	}

	public void treat() {
		super.treat();
		int gas = ((ResidentialBuilding) this.getTarget()).getGasLevel();
		gas -= 10;
		((ResidentialBuilding) this.getTarget()).setGasLevel(gas);
		this.jobsDone();
		
	}

	public void jobsDone() {
		
		
		if(((ResidentialBuilding) this.getTarget()).getGasLevel() == 0) {
			super.jobsDone();
		
	}
		
	}
	
}
