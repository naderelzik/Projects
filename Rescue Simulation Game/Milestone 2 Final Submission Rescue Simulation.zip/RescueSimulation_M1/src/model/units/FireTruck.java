package model.units;

import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;

public class FireTruck extends FireUnit{

	public FireTruck(String unitID, Address location, int stepsPerCycle, WorldListener listener) {

		super(unitID, location, stepsPerCycle, listener);

	}
	
	public void treat() {
		super.treat();
		int fire = ((ResidentialBuilding) this.getTarget()).getFireDamage();
		fire -= 10;
		((ResidentialBuilding) this.getTarget()).setFireDamage(fire);
		this.jobsDone();
		
	}
	
	public void jobsDone() {
		
		
		if(((ResidentialBuilding) this.getTarget()).getFireDamage() == 0) {
			
			super.jobsDone();
		}
		
	}

	

	

}
