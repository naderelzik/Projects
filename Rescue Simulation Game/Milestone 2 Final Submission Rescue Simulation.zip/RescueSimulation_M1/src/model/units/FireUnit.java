package model.units;

import model.events.SOSResponder;
import model.events.WorldListener;
import simulation.Address;

public abstract class FireUnit extends Unit implements SOSResponder{

	public FireUnit(String unitID, Address location, int stepsPerCycle, WorldListener listener) {

		super(unitID, location, stepsPerCycle, listener);

	}
	
	public void jobsDone() {
		super.jobsDone();
	}

}
