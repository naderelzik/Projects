package model.units;

import model.events.WorldListener;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;

public abstract class MedicalUnit extends Unit{

	private int healingAmount;
	private int treatmentAmount;

	public MedicalUnit(String unitID, Address location, int stepsPerCycle, WorldListener listener) {

		super(unitID, location, stepsPerCycle, listener);
		healingAmount = 10;
		treatmentAmount = 10;

	}

	public int getTreatmentAmount() {
		return treatmentAmount;
	}
	
	@Override
	public void respond(Rescuable r) {
		if(this.getState() == UnitState.TREATING && ((Citizen) this.getTarget()).getToxicity() == 0 && ((Citizen) this.getTarget()).getBloodLoss() == 0) {
			
		}
		
		else {
			super.respond(r);
		}

}
	
	public void treat() {
		super.treat();
		((Citizen) this.getTarget()).setState(CitizenState.RESCUED);
		if(((Citizen) this.getTarget()).getToxicity() == 0 && ((Citizen) this.getTarget()).getBloodLoss() == 0) {
			
			heal();
		}
	}
	
	public void heal() {
		int hp = ((Citizen) this.getTarget()).getHp();
		hp += this.healingAmount;
		((Citizen) this.getTarget()).setHp(hp);
		this.jobsDone();
	}
	
	public void jobsDone() {
		
		
		if(((Citizen) this.getTarget()).getHp() == 0) {
			super.jobsDone();
		}
		else if(((Citizen) this.getTarget()).getHp() == 100) {
			
			super.jobsDone();
	}
		
	}
	
}