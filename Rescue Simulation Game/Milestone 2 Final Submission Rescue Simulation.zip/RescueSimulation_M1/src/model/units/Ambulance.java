package model.units;

import model.events.WorldListener;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;

public class Ambulance extends MedicalUnit {

	public Ambulance(String unitID, Address location, int stepsPerCycle, WorldListener listener) {

		super(unitID, location, stepsPerCycle, listener);

	}

	public void treat() {
		super.treat();
		int BloodLoss = ((Citizen) this.getTarget()).getBloodLoss();
		BloodLoss -= this.getTreatmentAmount();
		((Citizen) this.getTarget()).setBloodLoss(BloodLoss);
	}

	public void jobsDone() {
		super.jobsDone();
		
		
	}
		
			
	}


