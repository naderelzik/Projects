import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientThread extends Thread {
	 int ID;
	 Socket connectionSocket;
	public ClientThread(int ID,Socket connectionSocket) {
		this.ID=ID;
		this.connectionSocket=connectionSocket;
	}
	
	String clientSentence;
	String capitalizedSentence;
	public DataOutputStream outToClient=null;
	
	
	public void run() {
		while(true) {
		BufferedReader inFromClient = null;
		try {
			inFromClient = new BufferedReader(new
					InputStreamReader(connectionSocket.getInputStream()));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		try {
			outToClient = new DataOutputStream(connectionSocket.getOutputStream());
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
		try {
			clientSentence = inFromClient.readLine();
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
		
		capitalizedSentence = clientSentence.toUpperCase() + '\n';
		
		try {
			outToClient.writeBytes(capitalizedSentence);
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
		
		if(clientSentence.equalsIgnoreCase("Close Socket"))
		{
			System.out.println("Connection Socket between the server and client is closed");
			System.out.println("===============================================");
			System.out.println("Server is Still Running......");
			
		}
		
	}
	}

}
