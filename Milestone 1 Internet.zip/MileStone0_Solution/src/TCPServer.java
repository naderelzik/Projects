import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

class TCPServer { 
	

	public static void main(String argv[]) throws Exception 
	{ 
		System.out.println("Server is ON......");
		ServerSocket welcomeSocket = new ServerSocket(6789); 
		ArrayList <ClientThread> clients = new ArrayList<>();
		
		while(true) {
			System.out.println("Waiting for connection.......");
			Socket connectionSocket = welcomeSocket.accept(); 
			System.out.println("Server is now connected to the Client");
			int ID = 0;
			ClientThread x = new ClientThread(ID,connectionSocket);
			x.start();
			clients.add(x);
			System.out.println(clients.toString());
			ID++;
			

		} 
	} 
} 


